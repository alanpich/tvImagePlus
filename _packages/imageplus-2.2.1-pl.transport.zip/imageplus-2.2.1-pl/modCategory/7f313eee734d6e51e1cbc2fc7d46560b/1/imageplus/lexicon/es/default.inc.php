<?php

$_lang['imageplus'] = "Image+";


$_lang['imageplus.editor_title'] = 'Image+ Editor';
$_lang['imageplus.edit_image'] = 'Edita la imagen';

/** Input options render **/
$_lang['imageplus.targetwidth'] = 'Ancho de la imagen';
$_lang['imageplus.targetwidth_desc'] = 'Ancho de la imagen a guardar';
$_lang['imageplus.targetheight'] = 'Alto de la imagen';
$_lang['imageplus.targetheight_desc'] = 'Alto de la imagen a guardar';
$_lang['imageplus.allowAltTag'] = 'Etiqueta Alt';
$_lang['imageplus.allowAltTag_desc'] = 'Permitir al usuario añadir un título/etiqueta alt a la imagen';

/** Output options render **/
$_lang['imageplus.phpThumbParams'] = 'Parámetros phpThumb adicionales';
$_lang['imageplus.phpThumbParams_desc'] = 'Añade filtros adicionales etc a phpThumb. La documentación se puede encontrar <a target="_blank" href="http://phpthumb.sourceforge.net/demo/docs/phpthumb.readme.txt">aquí</a>.';
$_lang['imageplus.outputChunk'] = 'Resultado chunk';
$_lang['imageplus.outputChunk_desc'] = 'Selecciona un chunk para obtener un resultado del tv. Dejar en vacío para obtener un resultado de la url cruda.';