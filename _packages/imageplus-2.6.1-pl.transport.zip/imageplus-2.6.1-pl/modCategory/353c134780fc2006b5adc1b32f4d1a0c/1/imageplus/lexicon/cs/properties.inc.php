<?php

/** Snippet properties */
$_lang['imageplus.imageplus.tvname'] = 'Název Image+ TV.';
$_lang['imageplus.imageplus.docid'] = 'Dokument, odkud je přebírána hodnota Image+ TV';
$_lang['imageplus.imageplus.type'] = 'Typ výstupu snippetu.  Může být nastaven na <i>check</i> <i>tpl</i> a <i>thumb</i>';
$_lang['imageplus.imageplus.options'] = 'Rozšířené možnosti nastavení pro phpThumb.';
$_lang['imageplus.imageplus.tpl'] = 'Chunk pro výstup snippetu.';
$_lang['imageplus.imageplus.value'] = 'Použijte vlastní JSON pro výstup snippetu. <i>tvname</i> a <i>docid</i> budou ignorovány.';