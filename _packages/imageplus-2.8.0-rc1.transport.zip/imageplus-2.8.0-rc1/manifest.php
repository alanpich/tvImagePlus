<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '01cb2a2019d8511f29e91ac46e63e196',
      'native_key' => 'imageplus',
      'filename' => 'modNamespace/170577c0e40fe7c99d1f4e8a45a74365.vehicle',
      'namespace' => 'imageplus',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffb7d0be9180f05a9d7615a8befbd963',
      'native_key' => 'imageplus.debug',
      'filename' => 'modSystemSetting/52b35569279b2eb619c424168765e6e6.vehicle',
      'namespace' => 'imageplus',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'decde02742d113dd2bb9b8ce1aa82778',
      'native_key' => 'imageplus.target_width',
      'filename' => 'modSystemSetting/fc24f39432821bcf18b5ea283b01b8b7.vehicle',
      'namespace' => 'imageplus',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '107138b8e1480d7c42d479c3990dea5f',
      'native_key' => 'imageplus.target_height',
      'filename' => 'modSystemSetting/ee70c26aefbd37775c3bbd1572837b31.vehicle',
      'namespace' => 'imageplus',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4972b2ac62c762f9dc0c8848f89904cd',
      'native_key' => 'imageplus.target_ratio',
      'filename' => 'modSystemSetting/68879bbccb8c6ffd7915e48efb03e6ed.vehicle',
      'namespace' => 'imageplus',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff96a2156a04f65c9b3181a3833d032b',
      'native_key' => 'imageplus.thumbnail_width',
      'filename' => 'modSystemSetting/6a445f2a43d5b154d1e3354d5bf2b1d2.vehicle',
      'namespace' => 'imageplus',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8723a0e7a66229b977da06d80eb337cb',
      'native_key' => 'imageplus.allow_alt_tag',
      'filename' => 'modSystemSetting/fcdc288c354d8e84ae2e6db024f4c507.vehicle',
      'namespace' => 'imageplus',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '161cba5f9c529b942f06069247df0fac',
      'native_key' => 'imageplus.allow_caption',
      'filename' => 'modSystemSetting/3fbd216e1d804dd42e9a1600892c97cc.vehicle',
      'namespace' => 'imageplus',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '632b490f7db1d20c9fcfdbed907b68be',
      'native_key' => 'imageplus.allow_credits',
      'filename' => 'modSystemSetting/d464f98687325849a906bca5eaaba995.vehicle',
      'namespace' => 'imageplus',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc5efa31740a67343ec3f1151bda7a48',
      'native_key' => 'imageplus.select_config',
      'filename' => 'modSystemSetting/2919afae56218eb6a62cdd0470f99d92.vehicle',
      'namespace' => 'imageplus',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '231d0035d6981f8cd9dfa5657702bf4d',
      'native_key' => 'imageplus.force_config',
      'filename' => 'modSystemSetting/3ec19ac1950d4101154fc71e464fa780.vehicle',
      'namespace' => 'imageplus',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f2a23dd4e349b9417fad39513a14fc54',
      'native_key' => NULL,
      'filename' => 'modCategory/000cf66fa2164072b1ee5037e4fc2fcc.vehicle',
      'namespace' => 'imageplus',
    ),
  ),
);