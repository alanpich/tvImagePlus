<?php
/** Snippet properties */
$_lang['imageplus.imageplus.docid'] = 'Ressource von welcher der Wert der Image+ TV geladen wird.';
$_lang['imageplus.imageplus.options'] = 'Erweiterte phpThumb Optionen für das Bild.';
$_lang['imageplus.imageplus.tpl'] = 'Template Chunk für die Snippet Ausgabe.';
$_lang['imageplus.imageplus.tvname'] = 'Name der Image+ TV.';
$_lang['imageplus.imageplus.type'] = 'Ausgabetyp des Snippets. Kann <i>check</i> <i>tpl</i> oder <i>thumb</i> enthalten.';
