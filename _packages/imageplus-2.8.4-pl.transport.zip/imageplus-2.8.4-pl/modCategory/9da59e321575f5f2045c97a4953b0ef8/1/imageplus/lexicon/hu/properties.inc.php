<?php
/** Snippet properties */
$_lang['imageplus.imageplus.docid'] = 'Az erőforrás, ahonnan az Image+ TV értéket kapja.';
$_lang['imageplus.imageplus.options'] = 'Kibővített phpThumb beállítások a képhez.';
$_lang['imageplus.imageplus.tpl'] = 'Sablondarab a snippet kimenethez.';
$_lang['imageplus.imageplus.tvname'] = 'Name of the Image+ TV.';
$_lang['imageplus.imageplus.type'] = 'A snippet kimenet típusa. Beállítható <i>check</i> <i>tpl</i> és <i>thumb</i>.';
