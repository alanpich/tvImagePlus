<?php

$_lang['imageplus'] = "Image+";


$_lang['imageplus.editor_title'] = 'Image+ Editor';
$_lang['imageplus.edit_image'] = 'Upravit obrázek';

/** Input options render **/
$_lang['imageplus.targetwidth'] = 'Cílová výška';
$_lang['imageplus.targetwidth_desc'] = 'Cílová výška pro výstupní obrázek';
$_lang['imageplus.targetheight'] = 'Cílová šířka';
$_lang['imageplus.targetheight_desc'] = 'Cílová šířka pro výstupní obrázek';
$_lang['imageplus.allowAltTag'] = 'Alt tag pole';
$_lang['imageplus.allowAltTag_desc'] = 'Povolit uživatelům zadat titulek/alt-tag pro obrázek';

/** Output options render **/
$_lang['imageplus.phpThumbParams'] = 'Další phpThumb parametry';
$_lang['imageplus.phpThumbParams_desc'] = 'Přidejte další filtry, např. pro phpThumb. Dokumentace je <a target="_blank" href="http://phpthumb.sourceforge.net/demo/docs/phpthumb.readme.txt">zde</a>.';
$_lang['imageplus.outputChunk'] = 'Výstupní chunk';
$_lang['imageplus.outputChunk_desc'] = 'Vyberte chunk pro výstup TV. Nechte prázdé pro výstup čisté URL.';