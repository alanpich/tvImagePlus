<?php
/**
 * Properties Lexicon Entries for Image+
 *
 * @package imageplus
 * @subpackage lexicon
 */
$_lang['imageplus.imageplus.docid'] = 'Recurso desde el que se recibe el valor de Image+ TV.';
$_lang['imageplus.imageplus.options'] = 'Opciones extendidas de phpThumb para la imagen.';
$_lang['imageplus.imageplus.tpl'] = 'Trozo de plantilla para la salida del fragmento.';
$_lang['imageplus.imageplus.tvname'] = 'Name of the Image+ TV.';
$_lang['imageplus.imageplus.type'] = 'Tipo de salida del snippet. Se puede establecer en <i>check</i> <i>tpl</i> y <i>thumb</i>.';
