<?php

/** Snippet properties */
$_lang['imageplus.imageplus.tvname'] = 'Имя TV c Image+.';
$_lang['imageplus.imageplus.docid'] = 'ID ресурса, из которого берется значение Image+ TV.';
$_lang['imageplus.imageplus.type'] = 'Тип вывода для сниппета. Может быть <i>check</i>, <i>tpl</i> и <i>thumb</i>.';
$_lang['imageplus.imageplus.options'] = 'Расширенные параметры phpThumb для изображения.';
$_lang['imageplus.imageplus.tpl'] = 'Чанк для оформления вывода сниппета.';
$_lang['imageplus.imageplus.value'] = 'Использовать собственные значения в JSON для вывода. Свойства <i>tvname</i> и <i>docid</i> игнорируются.';